PAD_TOKEN = '<pad>'
UNK_TOKEN = '<unk>'
SOS_TOKEN = '<bos>'
EOS_TOKEN = '<eos>'
